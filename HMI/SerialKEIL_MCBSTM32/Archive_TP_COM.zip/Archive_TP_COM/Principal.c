
#include "clock.h"
#include "API_ADC.h"
#include "Timer_1234.h"
#include "USART_rev2021.h"
#include "GPIO.h"
#include "FctDiverses_v2.h"
#include "API_Xbee_ModeAT_2022.h"
#include "LCD.h"

#include <string.h>
#include "stdio.h"





int main (void)
{
	CLOCK_Configure();

	
	while(1)	
	{
	}
	
}


